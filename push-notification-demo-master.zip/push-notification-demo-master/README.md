# Push Notification Demo
https://leocardoso94.github.io/push-notification-demo/

Repository to show how to receive notifications with firebase.

For more information see the articles:

English version: https://medium.freecodecamp.org/how-to-add-push-notifications-to-a-web-app-with-firebase-528a702e13e1

Portuguese version: https://medium.com/trainingcenter/adicionando-push-notifications-a-um-web-app-com-firebase-2a20cf12b6fe
